Afolashade Portfolio - Quick Setup

1) Upload everything to a PUBLIC GitHub repo, e.g. "afolashade-portfolio".
2) Enable GitHub Pages: Settings -> Pages -> Source = main branch, /root.
3) In index.html + sitemap.xml + robots.txt, replace YOUR_GITHUB_USERNAME with your actual GitHub username.
4) (Optional) When you buy a custom domain, create a CNAME file with your domain and update meta tags.
5) Contact Form: create a free Formspree form and replace YOUR_FORMSPREE_ID in index.html to receive messages.
